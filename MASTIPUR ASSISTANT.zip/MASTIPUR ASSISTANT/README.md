# Virtual-Assistant-


## Screenshots


![project](https://user-images.githubusercontent.com/51821426/208213987-b66bfc6b-4dc5-43fe-9354-c247395a850f.jpg)

## Installation

- you just need to run below cmd.
- it will be better if you creat virtual environment


```bash
  pip install -r requirement.txt
```
    
